# My Music Pack

This is a Minecraft resource pack for adding custom music.

## Usage

1. Place your .ogg music files in the `assets/minecraft/sounds/records/` directory.
2. To replace existing music discs, name your files like `music_disc_13.ogg`, `music_disc_cat.ogg`, etc.
3. For custom sounds, you may need to add entries to `sounds.json` in `assets/minecraft/`.

## Installation

Copy this folder to your Minecraft resourcepacks folder and enable it in the game.

## Troubleshooting

- Ensure .ogg files are in the correct format.
- Check pack.mcmeta for correct pack_format (34 for Minecraft 1.21).